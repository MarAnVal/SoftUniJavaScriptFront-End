let baseUrl = 'http://localhost:3030/jsonstore/gifts';
let items = {};
let idToEdit = undefined;

let inputDomElements = {
    giftInputElement: document.getElementById('gift'),
    forInputElement: document.getElementById('for'),
    priceInputElement: document.getElementById('price'),
}


let listElement = document.getElementById('gift-list');

let divListForm = document.querySelector('#gift-list div.gift-sock');
divListForm.style.display = 'none';

let buttonElements = {
    loadPresentButton: document.getElementById('load-presents'),
    addButtonElement: document.getElementById('add-present'),
    editButtonElement: document.getElementById('edit-present'),
}


buttonElements.loadPresentButton.addEventListener('click', loadItems);

buttonElements.addButtonElement.addEventListener('click', createItem);

buttonElements.editButtonElement.addEventListener('click', editItem);

function loadItems() {
    listElement.innerHTML = '';

    fetch(baseUrl)
        .then(response => response.json())
        .then(data => {
            for (let giftId in data) {
                attachElement(getListElement(data[giftId]));
                items[giftId] = data[giftId];
            }
        })
}

function attachElement(domElement) {
    listElement.appendChild(domElement);
}

function getListElement(gift) {
    let divElement = divListForm.cloneNode(true);

    divElement.setAttribute('id', gift._id);
    divElement.style.display = 'flex';

    divElement.querySelector('div.content p:nth-child(1)').textContent = gift['gift'];
    divElement.querySelector('div.content p:nth-child(2)').textContent = gift['for'];
    divElement.querySelector('div.content p:nth-child(3)').textContent = gift['price'];

    let editButtonElement = divElement.querySelector('.change-btn');
    editButtonElement.addEventListener('click', changeItem);

    let deleteButtonElement = divElement.querySelector('.delete-btn');
    deleteButtonElement.addEventListener('click', deleteItem);

    return divElement;
}

function createItem() {
    let gift = inputDomElements.giftInputElement.value;
    let forInput = inputDomElements.forInputElement.value;
    let price = inputDomElements.priceInputElement.value;
    if (gift && forInput && price) {
        let inputItem = {
            gift,
            'for': forInput,
            price,
        }

        fetch(baseUrl, {
            method: 'POST',
            headers: {
                'content-type': 'application/json',
            },
            body: JSON.stringify(inputItem),
        })
            .then(response => loadItems())

        clearInputFields();
    }
}

function editItem() {
    let gift = inputDomElements.giftInputElement.value;
    let forInput = inputDomElements.forInputElement.value;
    let price = inputDomElements.priceInputElement.value;
    if (gift && forInput && price) {
        let inputItem = {
            gift,
            'for': forInput,
            price,
            '_id': idToEdit,
        }
        let url = baseUrl + `/${idToEdit}`;

        fetch(url, {
            method: 'PUT',
            headers: {
                'content-type': 'application/json',
            },
            body: JSON.stringify(inputItem),
        })
            .then(response => clearInputFields())
            .then(data => {
                let addButtonElement = document.getElementById('add-present');
                addButtonElement.removeAttribute('disabled');
                let editButtonElement = document.getElementById('edit-present');
                editButtonElement.setAttribute('disabled', 'disabled');
                loadItems();
                idToEdit = undefined;
            });
    }
}

function changeItem(e) {
    idToEdit = e.target.parentElement.parentElement.id;
    inputDomElements.giftInputElement.value = items[idToEdit].gift;
    inputDomElements.forInputElement.value = items[idToEdit]['for'];
    inputDomElements.priceInputElement.value = items[idToEdit].price;

    let addButtonElement = document.getElementById('add-present');
    addButtonElement.setAttribute('disabled', 'disabled');
    let editButtonElement = document.getElementById('edit-present');
    editButtonElement.removeAttribute('disabled');

    e.target.parentElement.parentElement.remove();
}

function deleteItem(e) {
    let id = e.target.parentElement.parentElement.id;
    let url = baseUrl + `/${id}`

    fetch(url, {
        method: 'DELETE',
    })
        .then(response => {
            loadItems();
            delete items[id];
        });
}

function clearInputFields() {
    for (let selector in inputDomElements) {
        inputDomElements[selector].value = '';
    }
}